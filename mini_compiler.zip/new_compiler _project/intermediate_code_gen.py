temp_count = 0

def new_temp():
    global temp_count
    temp_count += 1
    return f"t{temp_count}"

def generate(ast):
    global temp_count
    temp_count = 0
    code = []

    def gen_expr(expr):
        if expr['type'] == 'num':
            return str(expr['value'])
        elif expr['type'] == 'var':
            return expr['value']
        elif expr['type'] == 'binop':
            left = gen_expr(expr['left'])
            right = gen_expr(expr['right'])
            temp = new_temp()
            code.append(f"{temp} = {left} {expr['op']} {right}")
            return temp

    for stmt in ast:
        if stmt['type'] in {'declaration', 'assignment'}:
            rhs = gen_expr(stmt['expr'])
            code.append(f"{stmt['var']} = {rhs}")
    return code
