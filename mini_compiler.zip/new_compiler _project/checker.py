import subprocess
import tempfile
import os
import mypy.api

def run_checker(code, language):
    """
    Run static analysis for the given code and language.
    Returns a string with the analysis result.
    """
    if language == "Python":
        # Write code to a temporary file for mypy
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as temp_file:
            temp_file.write(code)
            temp_file_path = temp_file.name

        try:
            # Run mypy for static type checking
            stdout, stderr, _ = mypy.api.run([temp_file_path])
            if stderr:
                return f"Type errors found:\n{stderr}"
            return "No type errors found."
        finally:
            os.unlink(temp_file_path)

    elif language == "C":
        # Write code to a temporary file for gcc
        with tempfile.NamedTemporaryFile(mode="w", suffix=".c", delete=False) as temp_file:
            temp_file.write(code)
            temp_file_path = temp_file.name

        try:
            # Run gcc with -fsyntax-only for syntax checking
            result = subprocess.run(
                ["gcc", "-fsyntax-only", temp_file_path],
                capture_output=True, text=True, timeout=5
            )
            if result.stderr:
                return f"Syntax errors found:\n{result.stderr}"
            return "No syntax errors found."
        finally:
            os.unlink(temp_file_path)

    elif language == "C++":
        # Write code to a temporary file for g++
        with tempfile.NamedTemporaryFile(mode="w", suffix=".cpp", delete=False) as temp_file:
            temp_file.write(code)
            temp_file_path = temp_file.name

        try:
            # Run g++ with -fsyntax-only for syntax checking
            result = subprocess.run(
                ["g++", "-fsyntax-only", temp_file_path],
                capture_output=True, text=True, timeout=5
            )
            if result.stderr:
                return f"Syntax errors found:\n{result.stderr}"
            return "No syntax errors found."
        finally:
            os.unlink(temp_file_path)

    elif language == "Java":
        # Write code to a temporary file with class name Main
        with tempfile.NamedTemporaryFile(mode="w", suffix=".java", delete=False) as temp_file:
            temp_file.write(code)
            temp_file_path = temp_file.name

        try:
            # Run javac for syntax checking
            result = subprocess.run(
                ["javac", temp_file_path],
                capture_output=True, text=True, timeout=5
            )
            if result.stderr:
                return f"Compilation errors found:\n{result.stderr}"
            return "No compilation errors found."
        finally:
            os.unlink(temp_file_path)

    return "Unsupported language."

def execute_code(code, language):
    """
    Execute the provided code in the specified language.
    Returns the output or error message.
    """
    try:
        if language == "Python":
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as temp_file:
                temp_file.write(code)
                temp_file_path = temp_file.name

            try:
                result = subprocess.run(
                    ["python", temp_file_path],
                    capture_output=True, text=True, timeout=5
                )
                return result.stdout if result.stdout else result.stderr or "No output."
            finally:
                os.unlink(temp_file_path)

        elif language == "C":
            with tempfile.NamedTemporaryFile(mode="w", suffix=".c", delete=False) as temp_file:
                temp_file.write(code)
                temp_file_path = temp_file.name

            try:
                # Compile
                executable = "a.out"
                compile_result = subprocess.run(
                    ["gcc", temp_file_path, "-o", executable],
                    capture_output=True, text=True, timeout=5
                )
                if compile_result.stderr:
                    return f"Compilation error:\n{compile_result.stderr}"

                # Run
                result = subprocess.run(
                    [f"./{executable}"],
                    capture_output=True, text=True, timeout=5
                )
                return result.stdout if result.stdout else result.stderr or "No output."
            finally:
                os.unlink(temp_file_path)
                if os.path.exists(executable):
                    os.unlink(executable)

        elif language == "C++":
            with tempfile.NamedTemporaryFile(mode="w", suffix=".cpp", delete=False) as temp_file:
                temp_file.write(code)
                temp_file_path = temp_file.name

            try:
                # Compile
                executable = "a.out"
                compile_result = subprocess.run(
                    ["g++", temp_file_path, "-o", executable],
                    capture_output=True, text=True, timeout=5
                )
                if compile_result.stderr:
                    return f"Compilation error:\n{compile_result.stderr}"

                # Run
                result = subprocess.run(
                    [f"./{executable}"],
                    capture_output=True, text=True, timeout=5
                )
                return result.stdout if result.stdout else result.stderr or "No output."
            finally:
                os.unlink(temp_file_path)
                if os.path.exists(executable):
                    os.unlink(executable)

        elif language == "Java":
            # Extract class name (assume public class Main for simplicity)
            with tempfile.NamedTemporaryFile(mode="w", suffix=".java", delete=False) as temp_file:
                temp_file.write(code)
                temp_file_path = temp_file.name

            try:
                # Compile
                compile_result = subprocess.run(
                    ["javac", temp_file_path],
                    capture_output=True, text=True, timeout=5
                )
                if compile_result.stderr:
                    return f"Compilation error:\n{compile_result.stderr}"

                # Run (assume class name is Main)
                result = subprocess.run(
                    ["java", "-cp", os.path.dirname(temp_file_path), "Main"],
                    capture_output=True, text=True, timeout=5
                )
                return result.stdout if result.stdout else result.stderr or "No output."
            finally:
                os.unlink(temp_file_path)
                class_file = temp_file_path.replace(".java", ".class")
                if os.path.exists(class_file):
                    os.unlink(class_file)

        return "Unsupported language."
    except subprocess.TimeoutExpired:
        return "Execution timed out."
    except Exception as e:
        return f"Error: {str(e)}"