symbol_table = {}

def analyze(ast):
    for stmt in ast:
        if stmt['type'] == 'declaration':
            symbol_table[stmt['var']] = stmt['data_type']
        elif stmt['type'] == 'assignment':
            if stmt['var'] not in symbol_table:
                raise Exception(f"Semantic Error: Undeclared variable '{stmt['var']}'")
            check_expr(stmt['expr'])
        else:
            raise Exception("Unknown statement type")

def check_expr(expr):
    if expr['type'] == 'num':
        return
    elif expr['type'] == 'var':
        if expr['value'] not in symbol_table:
            raise Exception(f"Semantic Error: Undeclared variable '{expr['value']}'")
    elif expr['type'] == 'binop':
        check_expr(expr['left'])
        check_expr(expr['right'])
