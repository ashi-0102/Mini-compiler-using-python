from flask import Flask, render_template, request, Response, jsonify
from lexer import tokenize
from parser import parse
from semantic import analyze
from intermediate_code_gen import generate
from optimizer import optimize
from codegen import generate_target_code
import re

app = Flask(__name__)
current_result = {}

@app.route('/', methods=['GET', 'POST'])
def index():
    global current_result
    result = {}
    if request.method == 'POST':
        code = request.form['code']

        print("📝 Submitted Code:")
        print(code)

        try:
            tokens = tokenize(code)
            print("🔤 Tokens:", tokens)

            ast = parse(code)
            print("🌳 AST:", ast)

            analyze(ast)
            print("✅ Semantic Analysis passed")

            tac = generate(ast)
            print("🧾 TAC:", tac)

            optimized = optimize(tac)
            print("✨ Optimized TAC:", optimized)

            target = generate_target_code(optimized)
            print("⚙️ Target Code:", target)

            result = {
                'tokens': tokens,
                'ast': str(ast),
                'tac': tac,
                'optimized': optimized,
                'target': target
            }
        except Exception as e:
            print("❌ Error:", e)
            result['error'] = str(e)

        current_result = result

    return render_template('index.html', result=current_result)

@app.route('/download/<string:type>')
def download(type):
    content_map = {
        'tac': '\n'.join(current_result.get('tac', [])),
        'optimized': '\n'.join(current_result.get('optimized', [])),
        'target': '\n'.join(current_result.get('target', []))
    }
    content = content_map.get(type, 'Invalid type.')
    return Response(content, mimetype='text/plain',
                    headers={'Content-Disposition': f'attachment;filename={type}.txt'})

# 🔍 New: Regex Checker Endpoint
@app.route('/regex', methods=['POST'])
def regex_check():
    pattern = request.form.get('pattern', '')
    test_string = request.form.get('test_string', '')
    try:
        if re.fullmatch(pattern, test_string):
            return jsonify({'result': f"✅ Match: '{test_string}' matches pattern '{pattern}'"})
        else:
            return jsonify({'result': f"❌ No match: '{test_string}' does NOT match pattern '{pattern}'"})
    except re.error as e:
        return jsonify({'result': f"⚠️ Invalid regex: {str(e)}"})

if __name__ == '__main__':
    app.run(debug=True)
