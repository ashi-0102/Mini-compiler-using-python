def generate_target_code(tac):
    return [f"LOAD {line}" for line in tac]
