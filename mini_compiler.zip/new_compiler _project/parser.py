from lexer import tokenize

def parse(code):
    tokens = tokenize(code)
    pos = 0
    ast = []

    def peek():
        return tokens[pos] if pos < len(tokens) else (None, None)

    def match(expected_type):
        nonlocal pos
        if pos < len(tokens) and tokens[pos][0] == expected_type:
            tok = tokens[pos]
            pos += 1
            return tok
        raise SyntaxError(f"Expected {expected_type}, got {tokens[pos]}")

    def expression():
        left = term()
        while True:
            tok = peek()
            if tok[0] == 'OP' and tok[1] in ('+', '-'):
                op = match('OP')
                right = term()
                left = {'type': 'binop', 'op': op[1], 'left': left, 'right': right}
            else:
                break
        return left

    def term():
        left = factor()
        while True:
            tok = peek()
            if tok[0] == 'OP' and tok[1] in ('*', '/'):
                op = match('OP')
                right = factor()
                left = {'type': 'binop', 'op': op[1], 'left': left, 'right': right}
            else:
                break
        return left

    def factor():
        tok = peek()
        if tok[0] == 'NUMBER':
            return {'type': 'num', 'value': match('NUMBER')[1]}
        elif tok[0] == 'ID':
            return {'type': 'var', 'value': match('ID')[1]}
        elif tok[0] == 'LPAREN':
            match('LPAREN')
            expr = expression()
            match('RPAREN')
            return expr
        else:
            raise SyntaxError("Invalid factor")

    while pos < len(tokens):
        tok = peek()
        if tok[0] in {'INT', 'FLOAT'}:
            dtype = match(tok[0])[1]
            var = match('ID')[1]
            match('ASSIGN')
            expr = expression()
            match('END')
            ast.append({'type': 'declaration', 'data_type': dtype, 'var': var, 'expr': expr})
        elif tok[0] == 'ID':
            var = match('ID')[1]
            match('ASSIGN')
            expr = expression()
            match('END')
            ast.append({'type': 'assignment', 'var': var, 'expr': expr})
        else:
            raise SyntaxError(f"Unexpected token: {tok}")
    return ast
