import re

def optimize(tac):
    optimized = []
    for line in tac:
        match = re.match(r'(t\d+) = (\d+) ([+\-*/]) (\d+)', line)
        if match:
            t, a, op, b = match.groups()
            a, b = int(a), int(b)
            result = eval(f"{a} {op} {b}")
            optimized.append(f"{t} = {result}")
        else:
            optimized.append(line)
    return optimized
